# 实际状态与缺口（2026-10-20）

| 环节 | 核查事实 | 状态 |
|---|---|---|
| 输入材料 | 1,043 个 zip 条目，解压体积 459,567,435 字节；含教程代码、GR-1/SO-101 USD 与贴图 | 已审计 |
| 训练数据 | zip 无 `datasets/`，本地未提供 SO-101 示教数据 | 缺失 |
| 模型权重 | zip 无 `.safetensors`、`.pt`、`.pth`，`finetuned/` 只有占位文件 | 缺失 |
| 运行环境 | Windows 11、Python 3.13.7；RTX 5060 Laptop，8,151 MiB 显存；缺 torch/gr00t/isaacsim/isaaclab | 无法直接运行原项目 |
| 原训练/服务 | 训练默认 GR-1 Exhaust pipe 数据，服务默认 GR-1 Nut pouring checkpoint | 配置不一致 |
| 原仿真通信 | SO-101 仿真用 ZMQ/MsgPack 5555，原真实服务用 HTTP 9876 `/inference` | 不兼容 |
| 原 NVIDIA 试验脚本 | HTTP `/predict` 未实现；另一脚本未支持模型时使用零动作；含未经确认的 WebRTC iframe 假设 | 不应当作已完成系统 |
| completion CPU 工程 | 统一 HTTP、双摄协议、明确 mock、按名映射、输入/动作检查、环境与数据审计、训练命令 | 已实现 |
| completion Isaac Sim runner | 无界面/有界 episode、动作 chunk、限位与跳变检查、异常关闭、日志 | 已写，未 GPU 验证 |
| 真正模型训练/任务评估 | 没有训练 loss、checkpoint、独立试验、成功判据或个人采集录像 | 未完成 |

## 原包媒体

- `results/SO101_Kitchen_Task.mp4`：445,657 字节，属于教程包提供的示例，不能证明个人训练或当前代码可复现。
- `results/NutPouring_batch32_nodiffusion.mp4`：仅 44 字节，不能作为有效实验视频。
- `dataset_images.png` 与资产缩略图：教程/资产示意，不是用户当前实验结果。
- 原包和上游仓库本次未找到项目级 LICENSE。公开站点使用这些媒体前应确认作者/资产许可；目前应优先放上游链接和自行绘制的流程说明。

## 阻碍真实闭环的必要输入

需要真实 SO-101 示教数据（含关节/夹爪单位、相机标定、控制频率），有足够资源且兼容的 Linux CUDA 训练环境，能正确解析资源并包含两台标定相机的 Isaac Sim 场景，以及训练后 checkpoint。当前工程没有伪造这些输入，也没有替代用户选择和付费配置远程 GPU。

`README.md` 给出逐步运行与验收方法。现有实现允许先验证数据/通信，再在真实环境完成 GPU 验收；不能据此宣称整个训练项目已经完成。
