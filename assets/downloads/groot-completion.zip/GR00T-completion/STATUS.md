# 实际状态与缺口（2026-10-20）

| 环节 | 核查事实 | 状态 |
|---|---|---|
| 输入材料 | 1,043 个 zip 条目，解压体积 459,567,435 字节；含教程代码、GR-1/SO-101 USD 与贴图 | 已审计 |
| 训练数据 | zip 无 `datasets/`，本地未提供 SO-101 示教数据 | 缺失 |
| 模型权重 | zip 无 `.safetensors`、`.pt`、`.pth`，`finetuned/` 只有占位文件 | 缺失 |
| 运行环境 | Windows 11、Python 3.13.7；RTX 5060 Laptop，8,151 MiB 显存；缺 torch/gr00t/isaacsim/isaaclab | 无法直接运行原项目 |
| 原训练/服务 | 训练默认 GR-1 Exhaust pipe 数据，服务默认 GR-1 Nut pouring checkpoint | 配置不一致 |
| 原仿真通信 | SO-101 仿真用 ZMQ/MsgPack 5555，原真实服务用 HTTP 9876 `/inference` | 不兼容 |
| 原 NVIDIA 试验脚本 | HTTP `/predict` 未实现；另一脚本未支持模型时使用零动作；含未经确认的 WebRTC iframe 假设 | 不应当作已完成系统 |
| completion CPU 工程 | 统一 HTTP、双摄协议、明确 mock、按名映射、输入/动作检查、环境与数据审计、训练命令 | 已实现 |
| completion Isaac Sim runner | 无界面/有界 episode、动作 chunk、限位与跳变检查、异常关闭、日志 | 已写，未 GPU 验证 |
| 真正模型训练/任务评估 | 没有训练 loss、checkpoint、独立试验、成功判据或个人采集录像 | 未完成 |

## 本次复核的三层结论

| 层级 | 已取得的证据 | 尚不能得出的结论 |
|---|---|---|
| 工程与 CPU 防护逻辑 | **12 项测试通过**；真实本地 HTTP 200/400；双摄缺失拒绝、NaN/限位/跳变拒绝、异常关闭、CUDA 预检、可选 zip 审计；两个入口语法检查通过 | 不代表 GPU 渲染、权重加载或神经网络计算通过 |
| 真实 GR00T 推理 | 已核对官方 `n1.5-release` 的构造参数、观察形状、双摄键和 checkpoint metadata 路径；缺失 checkpoint 时正常拒绝 | **未加载真实权重、未运行真实模型、未测推理性能** |
| Isaac Sim 训练任务 | runner 改用 Isaac Sim **5.1.0 legacy Core API** 的 `Robot.dof_properties`；修复日志/停止失败时漏关应用，以及 NaN 状态绕过动作检查的问题 | **未启动 Isaac Sim、未核验场景引用和相机、未做短训练/正式训练、未完成自主抓取评估** |

本次还修复了数据预检把“任意一个 mp4 存在”误当成双摄齐全的问题；现在会检查每个声明 episode 的两路非空视频与 parquet。预检仍不解码视频/parquet，不替代官方数据 loader。

## 原包媒体

- `results/SO101_Kitchen_Task.mp4`：445,657 字节，属于教程包提供的示例，不能证明个人训练或当前代码可复现。
- `results/NutPouring_batch32_nodiffusion.mp4`：仅 44 字节，不能作为有效实验视频。
- `dataset_images.png` 与资产缩略图：教程/资产示意，不是用户当前实验结果。
- 原包和上游仓库本次未找到项目级 LICENSE。公开站点使用这些媒体前应确认作者/资产许可；目前应优先放上游链接和自行绘制的流程说明。

## 阻碍真实闭环的必要输入

需要补齐以下输入，当前均未验收：

1. `completion/datasets/so101_kitchen/` 中的真实 LeRobot 演示：四份 meta、逐 episode parquet、front/wrist 视频，以及单位/时间对齐/控制频率说明。
2. `completion/models/GR00T-N1.5-3B/` 中完整的 base 模型与配套处理器文件；`completion/finetuned/so101_kitchen/` 中微调权重、`config.json` 和 `experiment_cfg/metadata.json`（`new_embodiment`）。
3. `completion/external/Isaac-GR00T/` 的兼容源码和审核后填写的 `source_commit`；可加载 CUDA PyTorch 的 Linux Python 3.10 训练环境。当前 `source_commit` 为空，没有声称已固定并安装远端代码。
4. Isaac Sim 运行环境，以及可解析全部引用、机器人固定状态正确、关节名称/限位已核对并包含两台标定相机的场景。现有 `GR00T/USD/` 资产确实存在，但不是已经验收的完整运行场景。
5. 物体放置成功判据、保留的测试回合/随机种子和原始录像。runner 的 `task_success` 仍为空。

当前工程没有伪造这些输入，也没有替代用户选择和付费配置远程 GPU。机器的 8GB 显存是否能容纳特定训练配置尚未验证；驱动报告的 CUDA 版本也不证明 PyTorch/CUDA 环境已安装。

`README.md` 给出逐步运行与验收方法。现有实现允许先验证数据/通信，再在真实环境完成 GPU 验收；不能据此宣称整个训练项目已经完成。
