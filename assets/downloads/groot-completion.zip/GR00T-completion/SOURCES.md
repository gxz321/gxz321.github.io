# 来源、版本与归属

核查时间：2026-10-20。以下是对应工程的第一方来源；本次通过网页读取了源码与说明，没有下载权重。

| 来源 | 用途与归属 |
|---|---|
| [donghoYee / Isaac-Sim-with-Gr00t-Tutorial](https://github.com/donghoYee/Isaac-Sim-with-Gr00t-Tutorial) | 与用户 zip 的文件结构/README 一致的教程上游。本次未找到 LICENSE；不能将其代码和视频整体标为个人原创或 Apache-2.0。|
| [NVIDIA / Isaac-GR00T，N1.5 分支](https://github.com/NVIDIA/Isaac-GR00T/tree/n1.5-release) | 本工程针对该分支 API；GR00T 源码的 Apache-2.0 许可不自动覆盖第三方教程、数据和模型权重。|
| [官方训练脚本](https://github.com/NVIDIA/Isaac-GR00T/blob/n1.5-release/scripts/gr00t_finetune.py) | 核实 CLI 参数、冻结模型选项、视频后端和日志配置。|
| [官方数据配置](https://github.com/NVIDIA/Isaac-GR00T/blob/n1.5-release/gr00t/experiment/data_config.py) | 核实 `so100_dualcam`、front/wrist、single_arm/gripper 及语言键。|
| [官方策略封装](https://github.com/NVIDIA/Isaac-GR00T/blob/n1.5-release/gr00t/model/policy.py) | 核实 `Gr00tPolicy` 构造、非 batch `(T,H,W,C)` 视频输入、`(T,D)` 状态与 checkpoint metadata。|
| [官方 LeRobot 数据格式](https://github.com/NVIDIA/Isaac-GR00T/blob/n1.5-release/getting_started/LeRobot_compatible_data_schema.md) | 核实数据目录和 modality 索引语义。|
| [GR00T N1.5 模型页](https://huggingface.co/nvidia/GR00T-N1.5-3B) | 取得权重前单独阅读模型许可和访问条件。|

原 zip SHA-256：`87ace0b8e551ff6b7291a1c2b9b5046240a64879ccd15a75545dcc628c8a4d29`。

`GR00T/NVIDIA/livestream.py` 自带 NVIDIA Apache-2.0 声明；其余同目录文件没有因此自动得到同一许可。`completion/` 中的新增工程保留为用户本地改进，没有擅自替原包添加开源许可。

`n1.5-release` 是分支名，可能变化。实际训练要求填写并验证 `source_commit`，输出目录会记录该 SHA 和完整命令；尚未在当前环境安装该分支，因此不虚构“已固定且跑通”的远端 commit。
