# GR00T × Isaac Sim：SO-101 仿真接入工程

本目录是对现有材料的工程补全，原始 zip、USD 和 NVIDIA 脚本均保留。目标是让数据、训练、策略服务与仿真共享同一份 SO-101 配置，并能区分“协议跑通”和“任务学会”。

**当前完成了 CPU 协议和工程检查；没有训练出模型，也没有完成 GPU 仿真验收。** 这台电脑未安装 `torch`、`gr00t` 或 `isaacsim`，没有训练数据及权重；Python 为 3.13.7，GPU 为 RTX 5060 Laptop 8GB。真实训练与 Isaac Sim 运行仍需独立环境、数据和 checkpoint。不能把原包中的示例视频写成个人训练成果。

## 已补全内容

- `configs/so101.json`：双摄像头、5 个机械臂关节 + 1 个夹爪、训练路径和服务端口统一配置。
- `pipeline.py`：原包审计、环境检查、LeRobot 结构检查、训练命令预览/执行、显式 mock/真实策略服务及客户端。
- `run_simulation.py`：有界 episode、按关节名映射、双摄输入、分块动作、网络超时、关节限位与单步跳变量检查、异常清理及运行记录。**本机仅做语法检查，未执行 Isaac Sim。**
- `tests/test_pipeline.py`：验证 HTTP 往返、RGB 尺寸、非法数值、缺失动作拒绝、关节重排与缺失数据。mock 仅返回当前姿态。
- `examples/modality.json`：SO-101 数据语义模板，不能代替采集数据。
- `STATUS.md`、`SOURCES.md`：实际完成状态、验收条件及材料来源。

## 1. 先在现有电脑执行 CPU 检查

在本目录打开终端，Python 3.10+ 即可运行；这些命令不安装软件、不下载模型。**单独下载并解压本工程包，也能运行 CPU 测试、mock 服务和训练命令预览，不需要原始教程 zip。**

```powershell
python pipeline.py doctor
python -m unittest discover -s tests -v
python pipeline.py train
python pipeline.py check-data
```

`train` 默认只打印参数列表；`check-data` 在尚无数据时返回退出码 2，并列出缺口，这正是预期行为。命令结果打印到终端。本地原始工程目录的 `reports/` 保存了本次检查结果；公开下载包不包含这些带本机路径的报告。

原始教程包审计是可选步骤。如果原 zip 与工程目录并列，默认命令会自动找到它；也可以显式指定路径：

```powershell
python pipeline.py audit
python pipeline.py audit --archive "C:\path\to\Isaac-Sim-with-Gr00t-Tutorial-main.zip"
```

找不到原包时，命令返回 JSON `status: skipped`、说明及用法提示，退出码仍为 0；这不会阻止其他 CPU 功能。找到有效 zip 时则返回 `status: completed`、SHA-256、文件条目和媒体审计。

在两个终端分别执行：

```powershell
# 终端 A：只持姿的测试服务
python pipeline.py serve --backend mock
```

```powershell
# 终端 B：通过实际 HTTP 发送双摄 RGB 和关节状态
python pipeline.py probe
```

返回 `backend: mock`、`actions` 表示传输和 shape 检查成功，不能说明模型具备抓取能力。服务默认只监听 `127.0.0.1:9876`，结束时按 Ctrl+C。

## 2. 建立真实训练环境

本项目针对官方 `n1.5-release` API；不要直接安装当前 main 并假设它与旧教程兼容。N1.5 的官方测试配置包含 Linux、Python 3.10 和 CUDA 12.4；具体硬件/依赖见 [NVIDIA 安装说明](https://github.com/NVIDIA/Isaac-GR00T/tree/n1.5-release#prerequisites)。这不代表本机 8GB 显存可以完成同样训练。可以把仿真和推理服务放在不同 GPU 主机上，但应先完成同机 loopback 验证。

以下是在准备好的 Linux GPU 主机上**手动执行**的步骤，本次没有执行这些安装或下载：

```bash
# 从 completion 目录开始
mkdir -p external
git clone --branch n1.5-release https://github.com/NVIDIA/Isaac-GR00T external/Isaac-GR00T
git -C external/Isaac-GR00T rev-parse HEAD

conda create -n gxz-gr00t-n15 python=3.10
conda activate gxz-gr00t-n15
cd external/Isaac-GR00T
pip install --upgrade setuptools
pip install -e '.[base]'
pip install --no-build-isolation flash-attn==2.7.1.post4
pip install tensorboard
cd ../..
```

检查上游 SHA 后，将完整 40 位值填入 `configs/so101.json` 的 `source_commit`，以后复现实验检出同一个 SHA。执行训练时会拒绝不匹配的 SHA 和有改动的上游源码，并记录 `gxz_run_manifest.json`。上述依赖来自 N1.5 分支说明，较新的 Blackwell GPU 仍需要验证对应 CUDA/PyTorch/FlashAttention 构建兼容性；不要将老的 CUDA 版本号机械套用到本机。

Isaac Sim 使用独立环境，按 [NVIDIA Isaac Sim 安装文档](https://docs.isaacsim.omniverse.nvidia.com/5.0.0/installation/index.html) 安装相匹配的 5.x 版本并先运行官方兼容性检查和空场景示例。此工程不需要 Isaac Lab；原 `new policy_inference.py` 所依赖的 leisaac/Isaac Lab 是另一条集成路线。

## 3. 准备真实 SO-101 数据

采集的每帧必须有同步的 front/wrist RGB、六关节状态、六关节目标动作与任务文本。当前接入约定：**绝对关节角，单位弧度**，顺序为 `shoulder_pan, shoulder_lift, elbow_flex, wrist_flex, wrist_roll, gripper`。USD 里的名称若不同，应以实际名称修改配置；同时核对采集系统的夹爪和角度单位，不能仅重命名数据字段。

将真实演示转换为 [GR00T LeRobot 数据格式](https://github.com/NVIDIA/Isaac-GR00T/blob/n1.5-release/getting_started/LeRobot_compatible_data_schema.md)，目录放到 `completion/datasets/so101_kitchen/`：

```text
meta/info.json
meta/modality.json
meta/episodes.jsonl
meta/tasks.jsonl
data/chunk-000/episode_000000.parquet
videos/chunk-000/observation.images.front/episode_000000.mp4
videos/chunk-000/observation.images.wrist/episode_000000.mp4
```

`examples/modality.json` 描述字段映射；帧、任务索引、episode 长度、视频时间戳及归一化统计必须来自真实采集。先运行 `python pipeline.py check-data`，再用官方 `LeRobotSingleDataset` 完成实际解码和首批数据读取，确认单位、动作时间对齐和 held-out episode 划分。这里的预检只验证结构，不声称视频及 parquet 可正确解码。

原包提供的是 GR-1 数据下载示例；GR-1 四组上肢关节不能直接作为 SO-101 的训练数据。没有提供通用“自动转换”脚本，因为现有材料中没有原始示教数据和单位规范。

## 4. 训练与启动真实策略

将完整、已授权取得的 N1.5 base checkpoint 放到 `completion/models/GR00T-N1.5-3B/`。本工具使用本地文件和 offline 模式，不会在启动时悄悄下载模型。

```bash
conda activate gxz-gr00t-n15
python pipeline.py train                # 审核生成的实际命令
python pipeline.py train --execute      # 前置检查通过后才启动训练
python pipeline.py serve --backend real
```

默认 batch=1、梯度累积=8、冻结 diffusion model 是一个保守的起始配置，**未验证显存可容纳或能收敛**。首次应将 `max_steps` 降到约 10、输出目录改为独立 smoke 路径，读取 loss 和显存记录后再设置正式实验。最终正式训练还需调参、验证集和 checkpoint 选择。

真实服务需要微调后的 SO-101 checkpoint，其中包含 `config.json`、权重及 `experiment_cfg/metadata.json`；缺少任何依赖或元数据会直接报错，不会切换到零动作。训练和推理的 `data_config`、`embodiment_tag` 必须一致。SO-101 使用 `new_embodiment`，不能直接把 GR-1 头当作 SO-101 策略。

## 5. 验证场景后运行 Isaac Sim

现有 USD 包含二进制文件；本机缺少 USD/Isaac Sim 运行库，因此没有验证其引用是否全部解析、机器人是否固定到桌面或相机是否标定。先在 Isaac Sim 打开目标场景，修复所有失效引用，再保存独立场景。推荐使用相对资源引用，保留 `GR00T/USD/` 的贴图目录关系。

在 Isaac Sim 自带 Python 或正确配置的独立环境中：

```bash
python run_simulation.py --stage /absolute/path/verified_scene.usd --inspect
```

`--inspect` 会列出 USD Camera 与 articulation root。把真实的机器人根和前置/手腕相机路径填入下面命令，不要照搬未核实的示例 prim：

```bash
python run_simulation.py \
  --stage /absolute/path/verified_scene.usd \
  --robot-prim /World/YourActualRobot \
  --front-camera /World/YourActualFrontCamera \
  --wrist-camera /World/YourActualRobot/YourActualWrist/Camera \
  --episodes 2 --steps 600 --control-hz 30 \
  --output results/so101_rollout.json
```

只有测试 mock 连接时加 `--allow-mock`。运行前逐项核对：六个关节名字、USD limits、夹爪单位、base 固定状态、相机实际画面、控制频率与示教频率。runner 会拒绝超限或跳变过大的目标；不应为让它继续运行而随意放宽门限。默认输出记录推理时延与步数，`task_success` 留空，等待真正的物体放置成功判据。

## 6. 完成任务验收的条件

1. 环境预检通过，固定源码 SHA、依赖版本和训练参数。
2. 真实数据可读取，双摄/状态/动作时间对齐，保留未参加训练的测试 episodes。
3. 短训练能前向/反向，正式训练保存 checkpoint、loss 和显存日志。
4. 真实服务完成一次合法观察推理，动作映射、单位和限位检查通过。
5. 至少完成固定随机种子的一组独立仿真测试，定义橙子进入目标容器并稳定保持的成功条件，逐回合保存成功/失败原因和原始录像。

在这些证据出现之前，网页适合表述为“基于 Isaac Sim 与 GR00T N1.5 的 SO-101 仿真和策略接入项目，工程链路完善中”，不展示训练成功率或把 mock 运行视为自主操作结果。
