"""Auditable GR00T N1.5 tooling; CPU checks use only the Python standard library."""
from __future__ import annotations

import argparse
import base64
import copy
import hashlib
import importlib.util
import importlib.metadata
import json
import math
import os
from pathlib import Path
import platform
import subprocess
import sys
import urllib.error
import urllib.request
import zipfile

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "configs" / "so101.json"
MAX_BODY = 2_000_000


def load_config(path=DEFAULT_CONFIG):
    path = Path(path).resolve()
    config = json.loads(path.read_text(encoding="utf-8"))
    for key in ("dataset_path", "checkpoint_path", "base_model_path", "gr00t_source"):
        config[key] = str((path.parent / config[key]).resolve())
    if config["data_config"] != "so100_dualcam":
        raise ValueError("This bridge implements so100_dualcam only; add a matching adapter for other robots.")
    if config["camera_names"] != ["front", "wrist"]:
        raise ValueError("so100_dualcam requires front and wrist cameras in that order.")
    if [len(x) for x in config["joint_groups"].values()] != [5, 1]:
        raise ValueError("SO-101 requires five arm joints and one gripper joint.")
    return config


def finite_vector(value, length, name):
    if not isinstance(value, list) or len(value) != length:
        raise ValueError(f"{name} must contain {length} numbers")
    if any(isinstance(x, bool) or not isinstance(x, (float, int)) or not math.isfinite(x) for x in value):
        raise ValueError(f"{name} must contain finite numbers")
    return [float(x) for x in value]


def validate_request(payload, config):
    if not isinstance(payload, dict) or payload.get("protocol") != "gxz-gr00t/1":
        raise ValueError("Expected protocol gxz-gr00t/1")
    task = payload.get("task")
    if not isinstance(task, str) or not task.strip() or len(task) > 2048:
        raise ValueError("task must be a nonempty string of at most 2048 characters")
    size = config["image_size"]
    cameras = payload.get("cameras")
    if not isinstance(cameras, dict) or set(cameras) != set(config["camera_names"]):
        raise ValueError("Both front and wrist RGB cameras are required")
    images = {}
    for name, frame in cameras.items():
        if not isinstance(frame, dict) or frame.get("shape") != [size, size, 3]:
            raise ValueError(f"{name} shape must be [{size}, {size}, 3] HWC")
        if frame.get("encoding") != "rgb8-base64":
            raise ValueError("Expected rgb8-base64 encoding")
        try:
            raw = base64.b64decode(frame["data"], validate=True)
        except (ValueError, TypeError, KeyError) as exc:
            raise ValueError(f"Invalid {name} base64") from exc
        if len(raw) != size * size * 3:
            raise ValueError(f"{name} byte length does not match RGB shape")
        images[name] = raw
    state = payload.get("state")
    if not isinstance(state, dict) or set(state) != set(config["joint_groups"]):
        raise ValueError("State must contain single_arm and gripper")
    parsed = {key: finite_vector(state[key], len(names), key) for key, names in config["joint_groups"].items()}
    return task, images, parsed


def validate_actions(actions, config):
    if not isinstance(actions, dict) or set(actions) != {"action.single_arm", "action.gripper"}:
        raise ValueError("Actions must contain action.single_arm and action.gripper")
    lengths = []
    for group, names in config["joint_groups"].items():
        values = actions[f"action.{group}"]
        if not isinstance(values, list) or not 1 <= len(values) <= config["action_horizon"]:
            raise ValueError("Action horizon is empty or exceeds the configured horizon")
        lengths.append(len(values))
        for row in values:
            finite_vector(row, len(names), f"action.{group}")
    if len(set(lengths)) != 1:
        raise ValueError("Arm and gripper action horizons differ")
    return actions


def action_in_joint_order(actions, timestep, dof_names, config):
    """Resolve each commanded joint by name; never assume USD articulation order."""
    validate_actions(actions, config)
    expected = [name for names in config["joint_groups"].values() for name in names]
    if len(dof_names) != len(set(dof_names)) or not set(expected).issubset(dof_names):
        raise ValueError(f"Articulation joints {dof_names} do not contain unique required joints {expected}")
    targets, indices = [], []
    for group, names in config["joint_groups"].items():
        for name, value in zip(names, actions[f"action.{group}"][timestep]):
            indices.append(dof_names.index(name))
            targets.append(value)
    return targets, indices


class PolicyBackend:
    def __init__(self, config, mode):
        self.config, self.mode = config, mode
        if mode == "real":
            checkpoint = Path(config["checkpoint_path"])
            if not (checkpoint / "config.json").is_file() or not (checkpoint / "experiment_cfg/metadata.json").is_file():
                raise ValueError("A local SO-101 checkpoint with config.json and experiment_cfg/metadata.json is required")
            # Never download weights implicitly when starting the local bridge.
            os.environ["HF_HUB_OFFLINE"] = "1"
            import torch
            if not torch.cuda.is_available():
                raise ValueError("Real GR00T inference requires a working CUDA PyTorch environment")
            from gr00t.experiment.data_config import load_data_config
            from gr00t.model.policy import Gr00tPolicy
            data = load_data_config(config["data_config"])
            self.policy = Gr00tPolicy(model_path=str(checkpoint), embodiment_tag=config["embodiment_tag"],
                                      modality_config=data.modality_config(), modality_transform=data.transform(), device="cuda")

    def predict(self, payload):
        task, images, state = validate_request(payload, self.config)
        if self.mode == "mock":
            # Hold current pose. This tests transport without pretending to solve a task.
            actions = {f"action.{key}": [values[:] for _ in range(self.config["action_horizon"])]
                       for key, values in state.items()}
        else:
            import numpy as np
            size = self.config["image_size"]
            obs = {f"video.{name}": np.frombuffer(raw, dtype=np.uint8).reshape(1, size, size, 3).copy()
                   for name, raw in images.items()}
            obs.update({f"state.{key}": np.asarray([values], dtype=np.float32) for key, values in state.items()})
            obs[self.config["language_key"]] = [task]
            actions = {key: value.tolist() for key, value in self.policy.get_action(obs).items()}
        return {"protocol": "gxz-gr00t/1", "backend": self.mode, "actions": validate_actions(actions, self.config)}


def make_server(config, mode, port=None):
    from http.server import BaseHTTPRequestHandler, HTTPServer
    backend = PolicyBackend(config, mode)

    class Handler(BaseHTTPRequestHandler):
        def reply(self, code, value):
            data = json.dumps(value, allow_nan=False).encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(data)))
            self.end_headers()
            self.wfile.write(data)

        def do_GET(self):
            if self.path == "/health":
                self.reply(200, {"status": "ready", "backend": mode, "protocol": "gxz-gr00t/1"})
            else:
                self.reply(404, {"error": "Use GET /health or POST /inference"})

        def do_POST(self):
            if self.path != "/inference":
                self.reply(404, {"error": "Unknown endpoint"})
                return
            try:
                self.connection.settimeout(config["server"]["timeout_s"])
                length = int(self.headers.get("Content-Length", "0"))
                if not 0 < length <= MAX_BODY:
                    raise ValueError("Request body is missing or too large")
                payload = json.loads(self.rfile.read(length))
                result = backend.predict(payload)
            except (ValueError, TypeError, KeyError) as exc:
                self.reply(400, {"error": str(exc), "backend": mode})
                return
            except Exception as exc:
                print(f"Policy inference failed: {exc}", file=sys.stderr)
                self.reply(503, {"error": "Policy inference failed; inspect server log", "backend": mode})
                return
            self.reply(200, result)

    # Sequential request handling also serializes GPU access.
    return HTTPServer((config["server"]["host"], config["server"]["port"] if port is None else port), Handler)


def sample_request(config):
    size = config["image_size"]
    frame = {"shape": [size, size, 3], "encoding": "rgb8-base64",
             "data": base64.b64encode(bytes(size * size * 3)).decode("ascii")}
    return {"protocol": "gxz-gr00t/1", "task": "Transport smoke test: hold current pose",
            "cameras": {name: copy.deepcopy(frame) for name in config["camera_names"]},
            "state": {key: [0.0] * len(names) for key, names in config["joint_groups"].items()}}


def request_action(payload, config):
    server = config["server"]
    url = f"http://{server['host']}:{server['port']}/inference"
    request = urllib.request.Request(url, json.dumps(payload, allow_nan=False).encode(), {"Content-Type": "application/json"})
    # Loopback traffic must not be routed through the user's external proxy.
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    with opener.open(request, timeout=server["timeout_s"]) as response:
        result = json.load(response)
    if not isinstance(result, dict) or result.get("protocol") != "gxz-gr00t/1" or result.get("backend") not in {"mock", "real"}:
        raise ValueError("Unexpected policy response")
    validate_actions(result.get("actions"), config)
    return result


def dataset_report(path, config):
    path = Path(path)
    errors, details = [], {}
    for name in ("info.json", "modality.json", "episodes.jsonl", "tasks.jsonl"):
        item = path / "meta" / name
        if not item.is_file():
            errors.append(f"Missing meta/{name}")
            continue
        try:
            value = json.loads(item.read_text(encoding="utf-8")) if name.endswith(".json") else [json.loads(line) for line in item.read_text(encoding="utf-8").splitlines() if line.strip()]
            if name.endswith(".json") and not isinstance(value, dict):
                errors.append(f"meta/{name} must be a JSON object")
                continue
            if name.endswith(".jsonl") and any(not isinstance(row, dict) for row in value):
                errors.append(f"meta/{name} must contain JSON objects")
                continue
            if not value:
                errors.append(f"meta/{name} is empty")
            details[name] = value
        except (ValueError, OSError) as exc:
            errors.append(f"Invalid meta/{name}: {exc}")
    modality = details.get("modality.json", {})
    for kind in ("state", "action", "video", "annotation"):
        if not isinstance(modality.get(kind, {}), dict):
            errors.append(f"modality.{kind} must be a JSON object")
            modality[kind] = {}
    for kind in ("state", "action"):
        offset = 0
        for group, names in config["joint_groups"].items():
            spec = modality.get(kind, {}).get(group, {})
            if not isinstance(spec, dict):
                spec = {}
            if (spec.get("start"), spec.get("end")) != (offset, offset + len(names)):
                errors.append(f"{kind}.{group} must cover [{offset}, {offset + len(names)})")
            if kind == "action" and spec.get("absolute") is not True:
                errors.append(f"action.{group} must explicitly declare absolute=true (radians)")
            offset += len(names)
    video = modality.get("video", {})
    for name in config["camera_names"]:
        camera_spec = video.get(name, {})
        if not isinstance(camera_spec, dict) or not camera_spec.get("original_key"):
            errors.append(f"Missing video.{name}.original_key")
    language = config["language_key"].removeprefix("annotation.")
    if language not in modality.get("annotation", {}):
        errors.append(f"Missing annotation.{language}")
    parquet = list(path.glob("data/**/*.parquet"))
    videos = list(path.glob("videos/**/*.mp4"))
    if not parquet:
        errors.append("No data/**/*.parquet files")
    if not videos:
        errors.append("No videos/**/*.mp4 files")
    # The dataset can contain arbitrary extra media; each required stream must
    # still exist for every declared episode before a dual-camera run can start.
    episodes = details.get("episodes.jsonl", [])
    episode_ids = []
    for episode in episodes:
        index, length = episode.get("episode_index"), episode.get("length")
        if isinstance(index, bool) or not isinstance(index, int) or index < 0:
            errors.append("Every episode must have a nonnegative integer episode_index")
            continue
        if isinstance(length, bool) or not isinstance(length, int) or length <= 0:
            errors.append(f"Episode {index} must declare a positive integer length")
        episode_ids.append(index)
        filename = f"episode_{index:06d}"
        if not any(item.stem == filename and item.stat().st_size > 0 for item in parquet):
            errors.append(f"Missing nonempty parquet data for {filename}")
        for name in config["camera_names"]:
            spec = video.get(name, {})
            original_key = spec.get("original_key") if isinstance(spec, dict) else None
            if original_key and not any(item.stem == filename and item.parent.name == original_key and item.stat().st_size > 0 for item in videos):
                errors.append(f"Missing nonempty video stream {original_key} for {filename}")
    if len(set(episode_ids)) != len(episode_ids):
        errors.append("meta/episodes.jsonl contains duplicate episode indices")
    return {"path": str(path.resolve()), "ok": not errors, "errors": errors,
            "parquet_files": len(parquet), "video_files": len(videos),
            "scope": "Structural preflight only; use official LeRobotSingleDataset loader to decode and validate rows before training."}


def source_report(archive=None):
    archive = Path(archive) if archive is not None else ROOT.parent / "Isaac-Sim-with-Gr00t-Tutorial-main.zip"
    if not archive.is_file():
        return {"status": "skipped", "reason": "Original tutorial archive is not available.",
                "hint": "CPU tests, mock service and training-command preview work without it. To audit an existing archive, use: python pipeline.py audit --archive PATH_TO_ZIP"}
    with archive.open("rb") as handle:
        digest = hashlib.sha256()
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
        checksum = digest.hexdigest()
    with zipfile.ZipFile(archive) as source:
        entries = source.infolist()
        return {"status": "completed", "archive": str(archive), "sha256": checksum,
                "entries": len(entries), "uncompressed_bytes": sum(x.file_size for x in entries),
                "license_paths": [x.filename for x in entries if any(t in x.filename.lower() for t in ("license", "copying", "notice"))],
                "datasets": [x.filename for x in entries if "/datasets/" in x.filename],
                "checkpoints": [x.filename for x in entries if x.filename.endswith((".safetensors", ".pt", ".pth"))],
                "media": [{"path": x.filename, "bytes": x.file_size} for x in entries if "/results/" in x.filename and not x.is_dir()]}


def doctor():
    modules = {name: bool(importlib.util.find_spec(name)) for name in ("torch", "gr00t", "isaacsim", "isaaclab", "numpy")}
    torch_probe = {"cuda_available": False, "status": "not_installed"}
    if modules["torch"]:
        try:
            probe = subprocess.run([sys.executable, "-c", "import json, torch; print(json.dumps({'cuda_available': torch.cuda.is_available(), 'torch_version': torch.__version__, 'cuda_build': torch.version.cuda}))"],
                                   capture_output=True, text=True, timeout=30)
            if probe.returncode == 0:
                torch_probe = dict(json.loads(probe.stdout.strip().splitlines()[-1]), status="loaded")
            else:
                torch_probe = {"cuda_available": False, "status": "import_failed", "error": probe.stderr.strip()[-1000:]}
        except (OSError, subprocess.TimeoutExpired, ValueError, IndexError) as exc:
            torch_probe = {"cuda_available": False, "status": "probe_failed", "error": str(exc)}
    try:
        gpu = subprocess.run(["nvidia-smi", "--query-gpu=name,memory.total,driver_version", "--format=csv,noheader"],
                             capture_output=True, text=True, timeout=10)
        gpu_text = gpu.stdout.strip() or gpu.stderr.strip()
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        gpu_text = str(exc)
    return {"python": platform.python_version(), "platform": platform.platform(), "modules": modules, "gpu": gpu_text,
            "torch_runtime": torch_probe,
            "training_ready": torch_probe["cuda_available"] and modules["gr00t"] and platform.system() == "Linux" and sys.version_info[:2] == (3, 10),
            "note": "training_ready checks Python, source-module presence and CUDA PyTorch, not sufficient VRAM, dataset validity, or convergence."}


def train_command(config):
    source = Path(config["gr00t_source"])
    train = config["training"]
    command = [sys.executable, str(source / "scripts/gr00t_finetune.py"),
               "--dataset-path", config["dataset_path"], "--output-dir", config["checkpoint_path"],
               "--base-model-path", config["base_model_path"], "--data-config", config["data_config"],
               "--embodiment-tag", config["embodiment_tag"], "--num-gpus", "1", "--no-tune-diffusion-model",
               "--report-to", "tensorboard"]
    for key, value in train.items():
        command.extend(["--" + key.replace("_", "-"), str(value)])
    return command


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    sub = parser.add_subparsers(dest="command", required=True)
    for name in ("doctor", "check-data", "probe"):
        sub.add_parser(name)
    audit = sub.add_parser("audit", help="Optionally inspect the original tutorial zip; skip when unavailable")
    audit.add_argument("--archive", type=Path, help="Path to an existing original tutorial zip")
    serve = sub.add_parser("serve")
    serve.add_argument("--backend", choices=("mock", "real"), required=True)
    train = sub.add_parser("train")
    train.add_argument("--execute", action="store_true")
    args = parser.parse_args()
    config = load_config(args.config)
    if args.command == "doctor":
        value = doctor()
    elif args.command == "audit":
        value = source_report(args.archive)
    elif args.command == "check-data":
        value = dataset_report(config["dataset_path"], config)
        print(json.dumps(value, ensure_ascii=False, indent=2))
        return 0 if value["ok"] else 2
    elif args.command == "probe":
        value = request_action(sample_request(config), config)
    elif args.command == "serve":
        server = make_server(config, args.backend)
        print(f"backend={args.backend} http://{server.server_address[0]}:{server.server_address[1]}", flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass
        finally:
            server.server_close()
        return 0
    elif args.command == "train":
        value = {"argv": train_command(config), "executed": False}
        if args.execute:
            report = dataset_report(config["dataset_path"], config)
            if not report["ok"]:
                raise ValueError("Dataset failed preflight: " + "; ".join(report["errors"]))
            if not doctor()["training_ready"]:
                raise ValueError("Use an isolated Linux Python 3.10 environment with the pinned GR00T installation")
            if not Path(value["argv"][1]).is_file() or not Path(config["base_model_path"], "config.json").is_file():
                raise ValueError("Install the GR00T source and place a complete base checkpoint in base_model_path first")
            output = Path(config["checkpoint_path"])
            if output.exists() and any(output.iterdir()):
                raise ValueError("Output directory is not empty; choose a new experiment directory")
            source = Path(config["gr00t_source"])
            revision = subprocess.check_output(["git", "-C", str(source), "rev-parse", "HEAD"], text=True).strip()
            if not config.get("source_commit") or revision != config["source_commit"]:
                raise ValueError("Set source_commit to the reviewed 40-character N1.5 checkout SHA before executing training")
            source_state = subprocess.check_output(["git", "-C", str(source), "status", "--porcelain"], text=True).strip()
            if source_state:
                raise ValueError("GR00T checkout has local changes; use a clean source for a reproducible run")
            output.mkdir(parents=True, exist_ok=True)
            packages = {}
            for package in ("torch", "transformers", "gr00t", "numpy", "flash-attn", "decord", "tensorboard"):
                try:
                    packages[package] = importlib.metadata.version(package)
                except importlib.metadata.PackageNotFoundError:
                    packages[package] = None
            (output / "gxz_run_manifest.json").write_text(json.dumps({"config": config, "argv": value["argv"], "gr00t_commit": revision,
                    "python": platform.python_version(), "packages": packages}, indent=2), encoding="utf-8")
            env = dict(os.environ, HF_HUB_OFFLINE="1")
            return subprocess.run(value["argv"], cwd=source, env=env, check=False).returncode
    print(json.dumps(value, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (ValueError, OSError, urllib.error.URLError) as exc:
        print(f"ERROR: {exc}", file=sys.stderr)
        raise SystemExit(2)
