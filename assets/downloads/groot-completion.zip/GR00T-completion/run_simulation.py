"""Isaac Sim 5.x runner for the completion bridge. Run --inspect before rollout.

The supplied USD stage must contain the robot and both calibrated cameras.
This entry point is syntax-checked locally; GPU execution needs Isaac Sim.
"""
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import time

from pipeline import action_in_joint_order, load_config, request_action, DEFAULT_CONFIG


def parse_args():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--stage", type=Path, required=True)
    parser.add_argument("--inspect", action="store_true", help="List camera and articulation prim paths, then close")
    parser.add_argument("--robot-prim")
    parser.add_argument("--front-camera")
    parser.add_argument("--wrist-camera")
    parser.add_argument("--task", default="Pick up the orange.")
    parser.add_argument("--headless", action="store_true")
    parser.add_argument("--allow-mock", action="store_true", help="Permit hold-pose transport checks; never count as task success")
    parser.add_argument("--episodes", type=int, default=2)
    parser.add_argument("--steps", type=int, default=600)
    parser.add_argument("--action-steps", type=int, default=8, help="Replan after this many policy steps")
    parser.add_argument("--control-hz", type=float, default=30)
    parser.add_argument("--max-joint-step", type=float, default=0.15, help="Reject targets that jump beyond this many radians per control tick")
    parser.add_argument("--output", type=Path, default=Path("results/rollout.json"))
    args = parser.parse_args()
    if not args.stage.is_file():
        parser.error("--stage must be an existing USD file")
    if not args.inspect and not all((args.robot_prim, args.front_camera, args.wrist_camera)):
        parser.error("rollout requires --robot-prim, --front-camera, and --wrist-camera; discover them with --inspect")
    if min(args.episodes, args.steps, args.action_steps, args.control_hz, args.max_joint_step) <= 0:
        parser.error("episode counts, step counts, control rate and jump limit must be positive")
    return args


def main():
    args = parse_args()
    config = load_config(args.config)
    from isaacsim import SimulationApp
    app = SimulationApp({"headless": args.headless})
    world = None
    report = {"backend": None, "task": args.task, "episodes": [], "task_success": None,
              "note": "Rollout completion does not imply task success. Add an object-placement success predicate and held-out trials before reporting a success rate."}
    try:
        import omni.usd
        from pxr import UsdGeom, UsdPhysics
        from isaacsim.core.utils.stage import is_stage_loading
        context = omni.usd.get_context()
        if not context.open_stage(str(args.stage.resolve())):
            raise ValueError("Isaac Sim could not open the USD stage")
        for _ in range(2):
            app.update()
        while is_stage_loading():
            app.update()
        stage = context.get_stage()
        if args.inspect:
            print(json.dumps({"cameras": [str(p.GetPath()) for p in stage.Traverse() if p.IsA(UsdGeom.Camera)],
                              "articulations": [str(p.GetPath()) for p in stage.Traverse() if p.HasAPI(UsdPhysics.ArticulationRootAPI)]}, indent=2))
            return
        for path in (args.robot_prim, args.front_camera, args.wrist_camera):
            if not stage.GetPrimAtPath(path).IsValid():
                raise ValueError(f"USD prim does not exist: {path}")
        for path in (args.front_camera, args.wrist_camera):
            if not stage.GetPrimAtPath(path).IsA(UsdGeom.Camera):
                raise ValueError(f"Expected a calibrated USD Camera at {path}")
        import numpy as np
        from isaacsim.core.api import World
        from isaacsim.core.api.robots import Robot
        from isaacsim.sensors.camera import Camera
        from isaacsim.core.utils.types import ArticulationAction
        world = World(stage_units_in_meters=1.0, physics_dt=1 / args.control_hz, rendering_dt=1 / args.control_hz)
        robot = world.scene.add(Robot(prim_path=args.robot_prim, name="so101"))
        cameras = {"front": Camera(prim_path=args.front_camera, resolution=(config["image_size"], config["image_size"])),
                   "wrist": Camera(prim_path=args.wrist_camera, resolution=(config["image_size"], config["image_size"]))}
        world.reset()
        names = list(robot.dof_names)
        # Validate the articulation mapping before receiving any policy actions.
        action_in_joint_order({"action.single_arm": [[0.0] * 5], "action.gripper": [[0.0]]}, 0, names, config)
        print("Articulation DOF order:", names)
        limits = np.asarray(robot.get_dof_limits()).reshape(-1, 2)
        for camera in cameras.values():
            camera.initialize()
        for episode in range(args.episodes):
            world.reset()
            for _ in range(60):
                world.step(render=True)
            record = {"episode": episode, "steps": 0, "inference_calls": 0, "latency_ms": [], "task_success": None}
            report["episodes"].append(record)
            chunk, chunk_step = None, 0
            for step in range(args.steps):
                if not app.is_running():
                    return
                positions = np.asarray(robot.get_joint_positions())
                if chunk is None or chunk_step >= min(args.action_steps, len(chunk["action.single_arm"])):
                    payload = {"protocol": "gxz-gr00t/1", "task": args.task, "cameras": {}, "state": {}}
                    for name, camera in cameras.items():
                        rgba = camera.get_rgba()
                        if rgba is None or tuple(rgba.shape)[:2] != (config["image_size"], config["image_size"]):
                            raise ValueError(f"Camera {name} is not ready or has the wrong resolution")
                        rgb = np.ascontiguousarray(rgba[:, :, :3], dtype=np.uint8)
                        payload["cameras"][name] = {"encoding": "rgb8-base64", "shape": list(rgb.shape),
                                                      "data": base64.b64encode(rgb.tobytes()).decode("ascii")}
                    for group, joint_names in config["joint_groups"].items():
                        payload["state"][group] = [float(positions[names.index(name)]) for name in joint_names]
                    start = time.perf_counter()
                    result = request_action(payload, config)
                    record["latency_ms"].append(round((time.perf_counter() - start) * 1000, 3))
                    if result["backend"] == "mock" and not args.allow_mock:
                        raise ValueError("Mock backend detected. Add --allow-mock only for a transport check")
                    report["backend"] = result["backend"]
                    chunk, chunk_step = result["actions"], 0
                    record["inference_calls"] += 1
                targets, indices = action_in_joint_order(chunk, chunk_step, names, config)
                target = np.asarray(targets)
                current = positions[indices]
                if np.any(target < limits[indices, 0]) or np.any(target > limits[indices, 1]):
                    raise ValueError("Policy target exceeds USD joint limits; check normalization and radians/degrees")
                if np.any(np.abs(target - current) > args.max_joint_step):
                    raise ValueError("Policy target jump exceeds --max-joint-step; inspect model units and control timing")
                robot.apply_action(ArticulationAction(joint_positions=target, joint_indices=np.asarray(indices)))
                world.step(render=True)
                record["steps"] = step + 1
                chunk_step += 1
    except Exception as exc:
        report["error"] = f"{type(exc).__name__}: {exc}"
        raise
    finally:
        if not args.inspect:
            args.output.parent.mkdir(parents=True, exist_ok=True)
            args.output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        if world is not None:
            world.stop()
        app.close()


if __name__ == "__main__":
    main()
