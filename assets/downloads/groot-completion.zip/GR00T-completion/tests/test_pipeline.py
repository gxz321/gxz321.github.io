import copy
import json
from pathlib import Path
import tempfile
import threading
import unittest
import urllib.error
import urllib.request
import zipfile

from pipeline import (action_in_joint_order, dataset_report, load_config, make_server,
                      request_action, sample_request, source_report, validate_actions, validate_request)


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.payload = sample_request(self.config)

    def test_roundtrip_and_mock_is_identified(self):
        server = make_server(self.config, "mock", port=0)
        self.config["server"]["port"] = server.server_port
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            self.payload["state"]["single_arm"] = [0.1, 0.2, -0.3, 0.0, 0.4]
            response = request_action(self.payload, self.config)
            self.assertEqual(response["backend"], "mock")
            self.assertEqual(response["actions"]["action.single_arm"][0], self.payload["state"]["single_arm"])
            self.assertEqual(len(response["actions"]["action.gripper"]), 16)
            self.payload["state"]["single_arm"] = [float("nan")] * 5
            # Server independently rejects nonfinite JSON from an unvalidated client.
            req = urllib.request.Request(f"http://127.0.0.1:{server.server_port}/inference", json.dumps(self.payload).encode())
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with self.assertRaises(urllib.error.HTTPError) as error:
                opener.open(req, timeout=3)
            self.assertEqual(error.exception.code, 400)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)

    def test_malformed_camera_and_states_rejected(self):
        for mutation in ("missing_camera", "shape", "encoding", "bytes", "nonfinite", "dimension"):
            payload = copy.deepcopy(self.payload)
            if mutation == "missing_camera":
                del payload["cameras"]["wrist"]
            elif mutation == "shape":
                payload["cameras"]["front"]["shape"] = [3, 256, 256]
            elif mutation == "encoding":
                payload["cameras"]["front"]["encoding"] = "jpeg"
            elif mutation == "bytes":
                payload["cameras"]["front"]["data"] = "AQID"
            elif mutation == "nonfinite":
                payload["state"]["gripper"] = [float("inf")]
            else:
                payload["state"]["single_arm"] = [0.0]
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate_request(payload, self.config)

    def test_joint_mapping_follows_usd_names(self):
        actions = {"action.single_arm": [[1, 2, 3, 4, 5]], "action.gripper": [[6]]}
        names = ["gripper", "wrist_roll", "wrist_flex", "elbow_flex", "shoulder_lift", "shoulder_pan"]
        targets, indices = action_in_joint_order(actions, 0, names, self.config)
        self.assertEqual(targets, [1, 2, 3, 4, 5, 6])
        self.assertEqual(indices, [5, 4, 3, 2, 1, 0])
        with self.assertRaises(ValueError):
            action_in_joint_order(actions, 0, ["unknown"], self.config)

    def test_missing_action_never_becomes_zero(self):
        with self.assertRaises(ValueError):
            validate_actions({"action.single_arm": [[0] * 5]}, self.config)
        with self.assertRaises(ValueError):
            validate_actions({"action.single_arm": [[0] * 5], "action.gripper": [[0], [0]]}, self.config)

    def test_empty_dataset_fails(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            report = dataset_report(Path(directory), self.config)
        self.assertFalse(report["ok"])
        self.assertGreaterEqual(len(report["errors"]), 6)

    def test_missing_source_archive_is_optional(self):
        report = source_report(Path(__file__).parent / "missing-original-tutorial.zip")
        self.assertEqual(report["status"], "skipped")
        self.assertIn("--archive", report["hint"])
        self.assertNotIn("sha256", report)

    def test_explicit_source_archive_is_audited(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            archive = Path(directory) / "tutorial.zip"
            with zipfile.ZipFile(archive, "w") as source:
                source.writestr("tutorial/results/example.mp4", b"example video bytes")
                source.writestr("tutorial/LICENSE", b"Example test license")
            report = source_report(archive)
        self.assertEqual(report["status"], "completed")
        self.assertEqual(report["entries"], 2)
        self.assertEqual(len(report["sha256"]), 64)
        self.assertEqual(report["license_paths"], ["tutorial/LICENSE"])
        self.assertEqual(report["media"][0]["bytes"], len(b"example video bytes"))


if __name__ == "__main__":
    unittest.main()
