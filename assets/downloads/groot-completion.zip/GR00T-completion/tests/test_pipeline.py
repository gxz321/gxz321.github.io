import copy
import json
import io
from pathlib import Path
import tempfile
import threading
import unittest
from unittest.mock import Mock, patch
import urllib.error
import urllib.request
import zipfile

from pipeline import (action_in_joint_order, dataset_report, doctor, load_config, make_server,
                      request_action, sample_request, source_report, validate_actions, validate_request)
from run_simulation import finalize_run, parse_args, validate_joint_targets


class ProtocolTests(unittest.TestCase):
    def setUp(self):
        self.config = load_config()
        self.payload = sample_request(self.config)

    def test_roundtrip_and_mock_is_identified(self):
        server = make_server(self.config, "mock", port=0)
        self.config["server"]["port"] = server.server_port
        thread = threading.Thread(target=server.serve_forever, daemon=True)
        thread.start()
        try:
            self.payload["state"]["single_arm"] = [0.1, 0.2, -0.3, 0.0, 0.4]
            response = request_action(self.payload, self.config)
            self.assertEqual(response["backend"], "mock")
            self.assertEqual(response["actions"]["action.single_arm"][0], self.payload["state"]["single_arm"])
            self.assertEqual(len(response["actions"]["action.gripper"]), 16)
            self.payload["state"]["single_arm"] = [float("nan")] * 5
            # Server independently rejects nonfinite JSON from an unvalidated client.
            req = urllib.request.Request(f"http://127.0.0.1:{server.server_port}/inference", json.dumps(self.payload).encode())
            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            with self.assertRaises(urllib.error.HTTPError) as error:
                opener.open(req, timeout=3)
            self.assertEqual(error.exception.code, 400)
        finally:
            server.shutdown()
            server.server_close()
            thread.join(timeout=3)

    def test_malformed_camera_and_states_rejected(self):
        for mutation in ("missing_camera", "shape", "encoding", "bytes", "nonfinite", "dimension"):
            payload = copy.deepcopy(self.payload)
            if mutation == "missing_camera":
                del payload["cameras"]["wrist"]
            elif mutation == "shape":
                payload["cameras"]["front"]["shape"] = [3, 256, 256]
            elif mutation == "encoding":
                payload["cameras"]["front"]["encoding"] = "jpeg"
            elif mutation == "bytes":
                payload["cameras"]["front"]["data"] = "AQID"
            elif mutation == "nonfinite":
                payload["state"]["gripper"] = [float("inf")]
            else:
                payload["state"]["single_arm"] = [0.0]
            with self.subTest(mutation=mutation), self.assertRaises(ValueError):
                validate_request(payload, self.config)

    def test_joint_mapping_follows_usd_names(self):
        actions = {"action.single_arm": [[1, 2, 3, 4, 5]], "action.gripper": [[6]]}
        names = ["gripper", "wrist_roll", "wrist_flex", "elbow_flex", "shoulder_lift", "shoulder_pan"]
        targets, indices = action_in_joint_order(actions, 0, names, self.config)
        self.assertEqual(targets, [1, 2, 3, 4, 5, 6])
        self.assertEqual(indices, [5, 4, 3, 2, 1, 0])
        with self.assertRaises(ValueError):
            action_in_joint_order(actions, 0, ["unknown"], self.config)

    def test_missing_action_never_becomes_zero(self):
        with self.assertRaises(ValueError):
            validate_actions({"action.single_arm": [[0] * 5]}, self.config)
        with self.assertRaises(ValueError):
            validate_actions({"action.single_arm": [[0] * 5], "action.gripper": [[0], [0]]}, self.config)

    def test_empty_dataset_fails(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            report = dataset_report(Path(directory), self.config)
        self.assertFalse(report["ok"])
        self.assertGreaterEqual(len(report["errors"]), 6)

    def test_missing_source_archive_is_optional(self):
        report = source_report(Path(__file__).parent / "missing-original-tutorial.zip")
        self.assertEqual(report["status"], "skipped")
        self.assertIn("--archive", report["hint"])
        self.assertNotIn("sha256", report)

    def test_explicit_source_archive_is_audited(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            archive = Path(directory) / "tutorial.zip"
            with zipfile.ZipFile(archive, "w") as source:
                source.writestr("tutorial/results/example.mp4", b"example video bytes")
                source.writestr("tutorial/LICENSE", b"Example test license")
            report = source_report(archive)
        self.assertEqual(report["status"], "completed")
        self.assertEqual(report["entries"], 2)
        self.assertEqual(len(report["sha256"]), 64)
        self.assertEqual(report["license_paths"], ["tutorial/LICENSE"])
        self.assertEqual(report["media"][0]["bytes"], len(b"example video bytes"))

    def test_dual_camera_preflight_rejects_a_missing_episode_stream(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            root = Path(directory)
            meta = root / "meta"
            meta.mkdir()
            (meta / "info.json").write_text('{"fps": 30}', encoding="utf-8")
            modality = Path(__file__).parent.parent / "examples" / "modality.json"
            (meta / "modality.json").write_text(modality.read_text(encoding="utf-8"), encoding="utf-8")
            (meta / "episodes.jsonl").write_text('{"episode_index": 0, "length": 1}', encoding="utf-8")
            (meta / "tasks.jsonl").write_text('{"task_index": 0, "task": "pick an orange"}', encoding="utf-8")
            (root / "data" / "chunk-000").mkdir(parents=True)
            # This test checks file presence, not parquet/video decoding.
            (root / "data" / "chunk-000" / "episode_000000.parquet").write_bytes(b"PAR1")
            for camera in ("front", "wrist"):
                stream = root / "videos" / "chunk-000" / f"observation.images.{camera}"
                stream.mkdir(parents=True)
                (stream / "episode_000000.mp4").write_bytes(b"structural-fixture")
            self.assertTrue(dataset_report(root, self.config)["ok"])
            (root / "videos" / "chunk-000" / "observation.images.wrist" / "episode_000000.mp4").unlink()
            report = dataset_report(root, self.config)
        self.assertFalse(report["ok"])
        self.assertTrue(any("observation.images.wrist" in error and "episode_000000" in error for error in report["errors"]))

    def test_joint_commands_reject_nan_state_and_unknown_limits(self):
        validate_joint_targets([0.1], [0.0], [[-1.0, 1.0]], 0.15)
        cases = [([0.1], [float("nan")], [[-1, 1]]),
                 ([0.1], [0.0], [[float("nan"), 1]]),
                 ([0.1], [0.0], [[1, -1]]),
                 ([1.1], [1.0], [[-1, 1]]),
                 ([0.8], [0.0], [[-1, 1]])]
        for targets, current, limits in cases:
            with self.subTest(targets=targets, current=current, limits=limits), self.assertRaises(ValueError):
                validate_joint_targets(targets, current, limits, 0.15)

    def test_simulation_closes_after_log_or_stop_failure(self):
        app, world, output = Mock(), Mock(), Mock()
        output.parent.mkdir.side_effect = OSError("report destination unavailable")
        with self.assertRaises(OSError):
            finalize_run(app, world, {}, output)
        world.stop.assert_called_once()
        app.close.assert_called_once()
        app, world = Mock(), Mock()
        world.stop.side_effect = RuntimeError("physics already stopped")
        with self.assertRaises(RuntimeError):
            finalize_run(app, world, {}, output, inspect=True)
        app.close.assert_called_once()

    def test_cli_rejects_nonfinite_control_timing_before_importing_isaac(self):
        with tempfile.TemporaryDirectory(dir=Path(__file__).parent) as directory:
            stage = Path(directory) / "scene.usda"
            stage.write_text("#usda 1.0", encoding="utf-8")
            for value in ("nan", "inf", "0"):
                with self.subTest(value=value), patch("sys.stderr", new=io.StringIO()), self.assertRaises(SystemExit) as error:
                    parse_args(["--stage", str(stage), "--inspect", "--control-hz", value])
                self.assertEqual(error.exception.code, 2)

    def test_torch_module_presence_does_not_imply_cuda_readiness(self):
        probe = Mock(returncode=0, stdout='{"cuda_available": false, "torch_version": "test", "cuda_build": null}', stderr="")
        gpu = Mock(stdout="test GPU", stderr="")
        # Windows platform.platform() can spawn its own subprocess in a cold
        # process. Isolate it so only the CUDA and GPU probes consume side_effect.
        with patch("pipeline.importlib.util.find_spec", return_value=object()), \
             patch("pipeline.subprocess.run", side_effect=[probe, gpu]), \
             patch("pipeline.platform.system", return_value="Linux"), \
             patch("pipeline.platform.platform", return_value="Linux-test-platform"), \
             patch("pipeline.sys.version_info", (3, 10)):
            report = doctor()
        self.assertFalse(report["training_ready"])
        self.assertFalse(report["torch_runtime"]["cuda_available"])


if __name__ == "__main__":
    unittest.main()
